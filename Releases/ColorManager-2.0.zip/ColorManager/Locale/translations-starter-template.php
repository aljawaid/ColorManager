<?php
return array(
  //
  // GENERAL
  //
  'A new way to utilise colors to their full potential in Kanboard. Choose from 3 color palettes, default, extra (includes white) or create your own. Across all palettes, choose from over 50 colors to match your workflow across the interface.' => '',
  //
  // ColorManagerContoller.php
  //
  'Settings' => '',
  'Color Manager' => '',
  'color-manager' => '',
  'Custom Colors' => '',
  'Add Color' => '',
  //
  // config/add_custom_color.php
  //
  'Color Name' => '',
  'Background Color' => '',
  'Border Color' => '',
  'Save Color' => '',
  //
  // config/colors.php
  //
  'Available Colors' => '',
  'Default Color Palette' => '',
  'These colors are part of the core. Pastel styles make these colors universal across all features of the application.' => '',
  'Task Color' => '',
  'Change the default color in' => '',
  'Project Settings' => '',
  'Go to Project Settings' => '',
  'Extra Color Palette' => '',
  'This palette shows a collection of colors different to those in the default palette. Selected colors also use alternative colors for text. These colors are particularly suitable for tags and categories.' => '',
  'Colors are named based on their common color name. If text colors are used, then the names are preceded by their text color.' => '',
  'Add to this palette' => '',
  'Custom Color Palette' => '',
  'This palette shows all user created colors. These colors are unique to your application.' => '',
  'Color names matching colors in other palettes will override those colors. Duplicate color names will not be created.' => '',
  'Delete Color' => '',
);
