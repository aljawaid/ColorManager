<?php
return array(
  //
  // GENERAL
  //
  'This plugin shows the actual colour values (background and matching border) for all the default Kanboard colours in the application settings.' => '',
  //
  // KBColoursContoller.php
  //
  'Default Colours' => '',
  //
  // config/colours.php
  //
  'Available Colours' => '',
  'Default Colour' => '',
  'Change the default colour in' => '',
  'Project Settings' => '',
  'Go to Project Settings' => '',
  'Total Colours' => '',
  'Background Colour' => '',
  'Border Colour' => '',
);
